import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import  { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule,FontAwesomeModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  passwordFieldType: string = 'password'; // Default input type

  togglePasswordVisibility() {
    // Toggle the input type between 'password' and 'text'
    this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password';
  }

}
